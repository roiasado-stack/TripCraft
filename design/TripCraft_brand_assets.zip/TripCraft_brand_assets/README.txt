TripCraft Brand Assets

01_app_icon      App icon exports in common sizes
02_full_logo     Full wordmark + slogan exports
03_color_variants Transparent, monochrome and background versions
04_icon_variants Monochrome app-icon versions
05_brand_spec    Colors and usage notes
